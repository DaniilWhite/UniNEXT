///INFLECTO TEAM ©2025///

///РАСПРОСТРАНЕНИЕ ЗАПРЕЩЕНО///

Требования и спецификации для запуска Сайта:
• Сайт работает Оффлайн, с возможностью расширения до Онлайна (подключение к серверу)
• Сайт использует архитектуру HTML5

Требования для запуска Сервера, Веб-проекта с расширениями:
• Microsoft ASP.NET, .NET, разработка веб-приложений
• C# (Входит в .NET)
• Dotnet SDK
• Microsoft Framework 10.0.0 (Dotnet)
• OpenAI API (Входит в комплект)
• NodeJS
• Запуск команд ниже для создания локальных серверов:
cd AISystem
cd Prototype
setx OPENAI_API_KEY "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"
dotnet run

(По необходимости) dotnet restore

cd AISystem
cd Prototype
cd wwwroot
node server.js

∆ - Для запуска Чат-Бота на основе gpt-4o / gpt-4o mini нужен ключ API с доступом к токенам!

///Веб-проект UniNEXT///
