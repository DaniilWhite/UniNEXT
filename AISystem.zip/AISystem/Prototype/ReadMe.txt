cd AISystem
cd Prototype
setx OPENAI_API_KEY "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"
dotnet run

dotnet restore


cd AISystem
cd Prototype
cd wwwroot
node server.js

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

setx OPENAI_API_KEY "твой_api_key_от_OpenAI"
